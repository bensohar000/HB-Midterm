# INF653 Midterm Project — Quotes REST API

**Author:** Your Name Here

**Live Project:** [https://your-project-url.com/api](https://your-project-url.com/api)

## About

A PHP OOP REST API for quotes built with PDO and MySQL.

## Endpoints

### Quotes
| Method | URL | Description |
|--------|-----|-------------|
| GET | /api/quotes/ | Get all quotes |
| GET | /api/quotes/?id=1 | Get quote by id |
| GET | /api/quotes/?author_id=1 | Get quotes by author |
| GET | /api/quotes/?category_id=1 | Get quotes by category |
| GET | /api/quotes/?author_id=1&category_id=1 | Get quotes by author and category |
| POST | /api/quotes/ | Create a quote |
| PUT | /api/quotes/ | Update a quote |
| DELETE | /api/quotes/ | Delete a quote |

### Authors
| Method | URL | Description |
|--------|-----|-------------|
| GET | /api/authors/ | Get all authors |
| GET | /api/authors/?id=1 | Get author by id |
| POST | /api/authors/ | Create an author |
| PUT | /api/authors/ | Update an author |
| DELETE | /api/authors/ | Delete an author |

### Categories
| Method | URL | Description |
|--------|-----|-------------|
| GET | /api/categories/ | Get all categories |
| GET | /api/categories/?id=1 | Get category by id |
| POST | /api/categories/ | Create a category |
| PUT | /api/categories/ | Update a category |
| DELETE | /api/categories/ | Delete a category |

## Tech Stack
- PHP (OOP)
- MySQL
- PDO
